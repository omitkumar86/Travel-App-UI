class Travel {
  String name;
  String address;
  String img;

  Travel(this.name, this.address, this.img);

  static List<Travel> generatedTravelInfoList() {
    return [
      Travel("Nusa Penida", "Bail, Indonesia", "images/nusa.jpg"),
      Travel("Raja Ampat", "Lombok, Indonesia", "images/raja.jpg"),
      Travel("Nusa Penida", "Bail, Indonesia", "images/nusa.jpg"),
      Travel("Raja Ampat", "Lombok, Indonesia", "images/raja.jpg"),
    ];
  }
}
